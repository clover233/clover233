# 启动类型判定 - 测试结果分析（2026-07-04）

测试场景：依次启动相机(Camera)、抖音(Aweme)、高德地图(AMapiPhone)、微信(WeChat)、微博(Weibo)。
日志来源：`result/launch_test_0704.log`（`APIHook.plist` 的 Filter 仍为 `com.apple.UIKit`，即所有 App 进程）。

## 总体结论

- **类型解码修复生效**：`taskState`/`debugState` 全部正常解出真实值，不再出现「未知返回类型编码」：
  - `taskState = running-active (原始值:4)`
  - `debugState = none (原始值:1)`
  这两个值与此前从系统二进制里提取的字符串常量（`running`/`running-active`/`running-suspended`）对得上，验证了 `NSStringFromRBSTaskState`/`NSStringFromRBSDebugState` 这两个私有转换函数确实生效。
- 相机管线的 Hook 1-4（`AVCaptureSession.startRunning`、`CVPixelBufferPoolCreate` 等）照常触发，没有回归。
- 过滤范围仍是全局生效：除 5 个主 App 外，还附带抓到了 `KonaSynthesizer`、`AMapiPhoneHomeWidgetExtension`、`WidgetExtension`(微博小组件) 等非主 App 进程。

## 各 App 启动类型判定结果

| App | PID | 判定结果 |
|---|---|---|
| Camera | 7089 | 冷启 → 冷启进前台 → ~6 秒后 `didEnterBackground` |
| 抖音 Aweme | 7093 | 冷启 → 冷启进前台 → ~5 秒后 `didEnterBackground` |
| 高德地图 AMapiPhone | 7101 | 冷启 → 冷启进前台 → `willEnterForeground`（切回）→ ~8 秒后 `didEnterBackground` |
| 微信 WeChat | 7102 | 冷启 → 冷启进前台 → `willEnterForeground` → 4 秒后 `didBecomeActive(非首次) → 热启/前台恢复`（同一 PID）→ `didEnterBackground` |
| 微博 Weibo | 7109 | 冷启 → 冷启进前台 → 连续 **3 次** `didBecomeActive(非首次) → 热启`（同一 PID 7109 反复前台恢复）→ `didEnterBackground` |

5 个 App 首次打开全部正确判定为冷启；微信、微博的二次前台切回也都正确判定为热启（PID 不变），逻辑符合预期。

## 值得注意的现象（非 bug）

**`taskState` 在 `didEnterBackground` 这一刻始终还是 `running-active`，没有观察到 `running-suspended`**——Camera/Aweme/高德/微信/微博这五个 App 刚进入后台的那次快照全都是这样。

合理解释：`UIApplicationDidEnterBackgroundNotification` 只代表 **UIKit 层面**的状态切换（"App 认为自己进后台了"），而 RunningBoard 真正把进程挂起（`running-active → running-suspended`）通常有一个宽限期（等后台任务断言过期，一般几秒到几十秒），并不与该通知同步发生。

**后续可选优化**：如果想真正抓到 `running-suspended`，需要在 `didEnterBackground` 之后**延迟几秒再补一次快照**（例如用 `dispatch_after` 延迟 5~10 秒再调用一次 `LogLaunchSnapshot`），而不是只在通知触发的瞬间看一次。此项待用户确认是否需要加入 `Tweak.x`。
