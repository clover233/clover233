# 启动类型判定 - 测试结果分析（2026-07-03）

测试场景：依次启动相机(Camera)、抖音(Aweme)、高德地图(AMapiPhone)、美团(imeituan)，然后再次启动高德地图。
日志来源：`result/launch_test_0703.log`（`APIHook.plist` 的 Filter 已放宽到 `com.apple.UIKit`，即所有 App 进程）。

## 总体结论

- **没有崩溃**，此前 `debugState` 因方法返回类型声明错误（误判为 `NSString*`，实际是整型枚举）导致的 `EXC_BAD_ACCESS` 已修复。
- **过滤范围验证符合预期**：除了手动打开的 4 个 App，还顺带捕获到 Spotlight、CacheDeleteExtension、KonaSynthesizer，以及高德/美团的 Widget、Live Activity 扩展进程（`AMapiPhoneHomeWidgetExtension`、`imeituanLiveActivity` 等）——说明确实不再局限于 Camera / Aweme 这两个示例 App。

## 各 App 启动类型判定结果

| App | PID | 判定结果 |
|---|---|---|
| Camera | 6987 | `didFinishLaunching → 冷启` → `didBecomeActive(首次) → 冷启直接进入前台`。约 32 秒后出现一次 `didEnterBackground → willEnterForeground → didEnterBackground` 的快速抖动（推测是快速切到后台又没完全切换回前台） |
| 抖音 Aweme | 6991 | 冷启 → 冷启进前台 → 11 秒后 `didEnterBackground` |
| 高德地图（第一次） | **7002** | 冷启 → 冷启进前台 → 5 秒后 `didBecomeActive(非首次) → 热启/前台恢复`（同一进程，说明切出去又很快切回来了）→ `didEnterBackground` |
| 高德地图（**再次启动**） | **7015**（全新 PID） | 冷启 → 冷启进前台 → `willEnterForeground` → `didEnterBackground`（有一次后台/前台来回） |
| 美团 imeituan | 7005 | 冷启 → 冷启进前台 → 连续两次 `didBecomeActive(非首次) → 热启` → `didEnterBackground` |

### 关键验证点：高德地图两次启动的对比

- 第一次启动进程号 `7002`，5 秒后 `didBecomeActive(非首次)` 被正确判定为热启（前台恢复），因为是**同一个进程**再次前台。
- 第二次「再启动」拿到的是**全新 PID `7015`**，说明两次操作之间进程已被系统或用户手动杀掉——因此被正确识别为冷启，而不是热启。
- 这组对比说明：**进程号是否复用**，是比 `taskState` 原始值更直接、更可靠的冷/热启动判定信号，和 HarmonyOS SmartGC 里冷启（0）/热启（10）的语义是对应的。

## 发现的问题及修复

`taskState` / `debugState` 全部输出：

```
未知返回类型编码 'C16@0:8'，已跳过避免类型不匹配崩溃
```

**原因**：这两个方法的真实返回类型是 `unsigned char`（Objective-C 类型编码里的大写 `C`），但运行时类型分派器 `LogRBSDynamicProperty` 之前只识别小写 `c`，漏掉了大写 `C`，于是被安全跳过，没能解码出最有信息量的字段。

**修复**：按真实宽度（`@`/`B`(BOOL)/`c`(char)/`C`(unsigned char)/`s`/`S`/`i`/`I`/`q`/`Q`/`l`/`L`）分别声明获取函数指针再调用——arm64 上标量返回值虽然都落在 `x0` 寄存器，但窄类型如果统一按 8 字节 `NSInteger` 硬读，高位会残留垃圾数据。修复后 `C` 类型会走整型分支，并配合 `NSStringFromRBSTaskState` / `NSStringFromRBSDebugState` 解码成可读字符串（如 `running-active` / `running-suspended` 等，与之前从系统二进制里提取的字符串常量对得上）。

本地已确认重新编译无警告无报错，需要重新 `make clean && make && make package && make install` 之后再测一轮，才能看到 `taskState`/`debugState` 的真实解码值。
