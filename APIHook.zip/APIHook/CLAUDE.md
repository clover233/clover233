# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

A Theos-based iOS tweak (jailbreak dylib injected via MobileSubstrate/Substitute) named `APIHook`. It hooks AVFoundation capture APIs, low-level CoreVideo pixel-buffer allocation functions, and RunningBoard/UIApplication lifecycle to log camera pipeline parameters and app launch-type classification at runtime. It's a reverse-engineering / instrumentation tool, not an app.

Target processes (see `APIHook.plist`):
- `Filter.Bundles = com.apple.UIKit` — the standard idiom for "inject into every app process that links UIKit" (i.e. effectively all foreground apps), not one specific bundle ID. `com.apple.camera` (Camera) and `com.ss.iphone.ugc.Aweme` (抖音/TikTok) are just the example apps used during development/testing — the camera-pipeline hooks (1–3 below) are simply inert no-ops in apps that never touch `AVCaptureSession`.
- `Filter.Executables = mediaserverd` (system media server executable) — for the low-level `CVPixelBuffer*` hooks.

`Makefile`'s `INSTALL_TARGET_PROCESSES = Camera Aweme` only controls which processes get killed for a quick reload after `make install`; it does not gate which processes the dylib loads into (that's the plist's job).

All logging goes through `NSLog` with an `[APIHook]` prefix, viewable via `oslog` on-device.

## Build & deploy commands

Requires Theos installed and `$THEOS` set. Device connection is configured for a USB-tunneled SSH (`THEOS_DEVICE_IP=localhost`, `THEOS_DEVICE_PORT=2222` in the Makefile) — start `iproxy 2222 22` in a separate terminal before install/run steps.

```sh
make clean && make               # build the tweak
make package                     # produce a .deb in packages/
make install                     # package + scp + install over ssh, then respring-equivalent
make clean && make && make package && make install   # full cycle, most common one-liner
```

`make install` triggers `after-install:: install.exec "killall -9 backboardd"` (kills SpringBoard's backboardd to reload injected processes — expect the screen to flicker/relock).

Theos's `install.exec`/`install.copyFile` scripts (`$THEOS/bin/`) shell out to plain `ssh`/`scp` with no password handling. For non-interactive automation (no TTY to type the password into), put `sshpass`-wrapped shims named `ssh`/`scp` earlier in `PATH` before invoking `make install`, e.g.:
```sh
mkdir -p /tmp/sshwrap
printf '#!/bin/bash\nexec sshpass -p "alpine" /usr/bin/ssh -o StrictHostKeyChecking=no "$@"\n' > /tmp/sshwrap/ssh
printf '#!/bin/bash\nexec sshpass -p "alpine" /usr/bin/scp -o StrictHostKeyChecking=no "$@"\n' > /tmp/sshwrap/scp
chmod +x /tmp/sshwrap/ssh /tmp/sshwrap/scp
PATH="/tmp/sshwrap:$PATH" make install
```

SSH to the device (password `alpine` unless changed):
```sh
ssh -p 2222 root@127.0.0.1
# or non-interactively:
sshpass -p 'alpine' ssh -p 2222 root@127.0.0.1
```

View logs on-device (`oslog` here appears to be a one-shot buffer dump, not a continuous stream — rerun it after triggering the event you want to capture, don't expect it to tail):
```sh
oslog | grep -E "\[APIHook\]"                  # everything the tweak logs, any process
oslog | grep -E "\[APIHook\]\[LaunchType\]"    # just the launch-type classifier
oslog | grep -E "\[APIHook\]|Camera"           # scoped to Camera app testing
oslog | grep -E "\[APIHook\]|Aweme"            # scoped to Aweme app testing
oslog | grep -E "\[APIHook\]|mediaserverd"
```

There is no lint/test suite — validation is done by installing on-device and reading `oslog` output against a real capture session.

## Architecture

`Tweak.x` is the single source file, organized as independent hook blocks:

1. **`%hook AVCaptureVideoDataOutput`** — logs `setVideoSettings:`/`videoSettings` (pixel format, resolution) and `setAlwaysDiscardsLateVideoFrames:`. This is the application-layer view of what format the app requests from the capture pipeline.

2. **`%hook AVCaptureSession`** — logs `setSessionPreset:`, `addOutput:`, `addInput:`, and on `startRunning` dumps a summary: preset, input/output counts, and per-`AVCaptureDeviceInput` active format (resolution + max frame rate via `CMVideoFormatDescriptionGetDimensions`). This is the pipeline-assembly view — best place to see the full session config at the moment capture starts.

3. **`CVPixelBufferPoolCreate`** and **`CVPixelBufferCreate`** — hooked via `MSHookFunction` (C function hooking, not Objective-C method hooking, since these are CoreVideo C APIs) instead of `%hook`. Each keeps an `orig_*` function pointer set in the `%ctor`. These are the lowest-level allocation points and log actual buffer/pool memory sizes (logical `CVPixelBufferGetDataSize` vs physical `IOSurfaceGetAllocSize`), independent of what the app layer requested — useful for spotting discrepancies between requested and actually-allocated formats.

Helper functions `FourCCToString` and `FrameMemoryDescription` are used across hooks to render pixel format codes (e.g. `'420v'`) and estimate per-frame memory by format (NV12/BiPlanar 4:2:0, 'x420', BGRA/RGBA, 'yuvs', etc.).

4. **App launch-type classification** — not tied to camera capture at all; runs in any UIApplication process the dylib loads into. Combines:
   - `RBSProcessHandle`/`RBSProcessState` (private classes from `RunningBoardServices.framework`, no public header — declared manually in `Tweak.x` based on method names verified via `nm` against Xcode's cached device-support symbols for the exact connected device/build). `+[RBSProcessHandle currentProcess]` → `-currentState` gives the live RunningBoard task state.
   - `NSStringFromRBSTaskState`, a real exported C function from `RunningBoardServices` (confirmed via the SDK's `.tbd`), resolved at runtime with `dlopen`/`dlsym` (not linked at build time) to decode the raw `taskState` integer into a human-readable string instead of hardcoding the private enum.
   - Standard `UIApplicationDidFinishLaunching/DidBecomeActive/WillEnterForeground/DidEnterBackground` notifications plus a `getenv("ActivePrewarm")` check and a "seen `didBecomeActive` before" flag, to classify cold launch vs. prewarm vs. warm/resume (same process re-foregrounded) vs. likely system-initiated background launch (enters background without ever becoming active) — see `LogLaunchSnapshot()` and the notification block inside `%ctor`.
   - This whole block is skipped when `NSClassFromString(@"UIApplication")` is nil (i.e. non-UI processes like `mediaserverd`).

All hook groups are wired up in the single `%ctor` at the bottom of the file: `%init()` activates the Logos-generated `%hook` blocks, two explicit `MSHookFunction` calls patch the C-level CoreVideo hooks, and the `dlopen`/`dlsym` + notification-observer setup wires up the launch-type classifier.

**Layering note:** the three camera-pipeline logging levels (app-layer `AVCaptureVideoDataOutput`/`AVCaptureSession`, and low-level `CVPixelBuffer*`) are intentionally kept separate rather than consolidated, so log output can be diffed to catch cases where the app's requested format doesn't match what actually gets allocated. When extending, prefer hooking at the application layer (`AVFoundation`) first — mediaserverd's private capture stack (`BWFigCaptureDevice`, `FigCaptureSession`, etc.) requires reverse-engineering private function signatures and is significantly more involved; only drop to that layer if the AVFoundation-layer hooks don't surface the needed data.

**Finding private API signatures:** before hooking an undocumented class/function, check `~/Library/Developer/Xcode/iOS DeviceSupport/<model> <version> (<build>)/Symbols/System/Library/PrivateFrameworks/` for a symbol-rich copy of the exact framework version running on the connected device (Xcode caches these automatically once a device has been connected there). `nm -Uj` on the binary inside yields real `-[Class method]` names — far more reliable than guessing from blog posts or older iOS versions.



## APP Launch API documentation references

The launch-type classifier mixes two very different kinds of API — worth knowing which is which before trusting a signal from it:

**Public, documented (UIKit notifications used in `%ctor`):**
- [`UIApplication.didFinishLaunchingNotification`](https://developer.apple.com/documentation/uikit/uiapplication/didfinishlaunchingnotification)
- [`UIApplication.didBecomeActiveNotification`](https://developer.apple.com/documentation/uikit/uiapplication/didbecomeactivenotification)
- [`UIApplication.willEnterForegroundNotification`](https://developer.apple.com/documentation/uikit/uiapplication/willenterforegroundnotification)
- [`UIApplication.didEnterBackgroundNotification`](https://developer.apple.com/documentation/uikit/uiapplication/didenterbackgroundnotification)
- [`application(_:didFinishLaunchingWithOptions:)`](https://developer.apple.com/documentation/uikit/uiapplicationdelegate/application(_:didfinishlaunchingwithoptions:)) — the delegate-method equivalent of the first notification
- [`UIApplication.State`](https://developer.apple.com/documentation/uikit/uiapplication/state) / [`applicationState`](https://developer.apple.com/documentation/uikit/uiapplication/applicationstate) — the `.active`/`.inactive`/`.background` enum these notifications track. These doc pages are thin (one-line description, no parameter table) because `NSNotification` only carries `name`/`object`/`userInfo`, and `userInfo` isn't used here.

**Private, undocumented (RunningBoard state in `LogRBSDynamicProperty`/`LogLaunchSnapshot`):**
`RBSProcessHandle`, `RBSProcessState`, `NSStringFromRBSTaskState`, `NSStringFromRBSDebugState` are all from `RunningBoardServices.framework` — an Apple-internal private framework with no public header and no developer.apple.com page, and there never will be one. The method/function names here came from `nm` against Xcode's cached device-support symbols (see the Architecture section above), not from documentation.

**`ActivePrewarm` env var caveat:** this was never public API either — it's an implementation detail an Apple DTS engineer described on the developer forums ([iOS 15 prewarming and didFinishLaunching](https://developer.apple.com/forums/thread/706782), [iOS 15 - prewarming - background](https://developer.apple.com/forums/thread/700437)), and those same forum threads report it may no longer be reliably set on iOS 16+. Every test run so far on this iOS 16.1 device has logged `ActivePrewarm 环境变量 = (未设置)` for every app — that's consistent with either "none of these launches were prewarmed" or "the signal doesn't fire on this OS version anymore," and the two aren't currently distinguishable. If validating prewarm detection specifically, the forum thread suggests apps with an active Live Activity get prewarmed right after a reboot (before first unlock) — that's the one scenario that still reliably triggers it.

## Repo housekeeping notes

- `packages/` accumulates every build's `.deb` (currently 100+ files) and `result/` holds ad-hoc investigation logs/slides from past debugging sessions — both are build/analysis output, not source.
- `.gitignore` is currently deleted in the working tree (git status shows `D .gitignore`); it previously ignored `.DS_Store`, `.theos`, and `packages`. Restore or update it before committing if that removal wasn't intentional.
- `hilog` at the repo root currently contains an unrelated OpenHarmony/`hdc` log capture (not iOS `oslog` output) — likely a stray/mistaken paste rather than project data.




