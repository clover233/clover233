#include <objc/message.h>
#include <objc/runtime.h>
#include <substrate.h>
#include <stdio.h>
#include <dlfcn.h>
#include <AVFoundation/AVFoundation.h>
#include <CoreVideo/CoreVideo.h>
#include <IOSurface/IOSurfaceRef.h>
#include <UIKit/UIKit.h>

// ─────────────────────────────────────────────
// 辅助：将 FourCC 转成可读字符串，如 '420v'
// ─────────────────────────────────────────────
static NSString *FourCCToString(uint32_t code) {
    char chars[5] = {
        (char)((code >> 24) & 0xFF),
        (char)((code >> 16) & 0xFF),
        (char)((code >>  8) & 0xFF),
        (char)( code        & 0xFF),
        0
    };
    return [NSString stringWithFormat:@"0x%X ('%s')", code, chars];
}

// ─────────────────────────────────────────────
// Hook 1: AVCaptureVideoDataOutput (应用层参数)
// ─────────────────────────────────────────────
%hook AVCaptureVideoDataOutput

- (void)setVideoSettings:(NSDictionary<NSString *,id> *)videoSettings {
    NSLog(@"[APIHook] ======= AVCaptureVideoDataOutput.setVideoSettings =======");
    if (videoSettings) {
        NSNumber *pixelFormat = videoSettings[(id)kCVPixelBufferPixelFormatTypeKey];
        if (pixelFormat) NSLog(@"[APIHook] 像素格式: %@", FourCCToString([pixelFormat unsignedIntValue]));
        
        NSNumber *width  = videoSettings[(id)kCVPixelBufferWidthKey];
        NSNumber *height = videoSettings[(id)kCVPixelBufferHeightKey];
        if (width && height) NSLog(@"[APIHook] 视频分辨率: %@ x %@", width, height);
    }
    %orig(videoSettings);
}

- (NSDictionary<NSString *,id> *)videoSettings {
    NSDictionary *settings = %orig;
    if (settings) {
        NSNumber *width  = settings[(id)kCVPixelBufferWidthKey];
        NSNumber *height = settings[(id)kCVPixelBufferHeightKey];
        if (width && height) {
            NSLog(@"[APIHook] ======= AVCaptureVideoDataOutput.videoSettings (GET) =======");
            NSLog(@"[APIHook] 当前视频分辨率: %@ x %@", width, height);
        }
    }
    return settings;
}

- (void)setAlwaysDiscardsLateVideoFrames:(BOOL)alwaysDiscards {
    NSLog(@"[APIHook] ======= AVCaptureVideoDataOutput.setAlwaysDiscardsLateVideoFrames =======");
    NSLog(@"[APIHook] 丢帧开关: %@", alwaysDiscards ? @"YES" : @"NO");
    %orig(alwaysDiscards);
}

%end

// ─────────────────────────────────────────────
// Hook 2: AVCaptureSession (流管线总览)
// ─────────────────────────────────────────────
%hook AVCaptureSession

- (void)setSessionPreset:(AVCaptureSessionPreset)sessionPreset {
    NSLog(@"[APIHook] ======= AVCaptureSession.setSessionPreset =======");
    NSLog(@"[APIHook] 画质(Preset): %@", sessionPreset);
    %orig(sessionPreset);
}

- (void)addOutput:(AVCaptureOutput *)output {
    %orig(output);
    NSLog(@"[APIHook] ======= AVCaptureSession.addOutput =======");
    NSLog(@"[APIHook] 新增 output 类型: %@", NSStringFromClass([output class]));
}

- (void)addInput:(AVCaptureInput *)input {
    %orig(input);
    NSLog(@"[APIHook] ======= AVCaptureSession.addInput =======");
    NSLog(@"[APIHook] 新增 input 类型: %@", NSStringFromClass([input class]));
}

- (void)startRunning {
    NSLog(@"[APIHook] ======= AVCaptureSession.startRunning（汇总）=======");
    NSLog(@"[APIHook] 画质(Preset): %@", self.sessionPreset);
    NSLog(@"[APIHook] inputs 数量: %lu | outputs 数量: %lu", (unsigned long)self.inputs.count, (unsigned long)self.outputs.count);

    for (AVCaptureInput *input in self.inputs) {
        if ([input isKindOfClass:[%c(AVCaptureDeviceInput) class]]) {
            AVCaptureDeviceInput *deviceInput = (AVCaptureDeviceInput *)input;
            AVCaptureDevice *device = deviceInput.device;
            CMFormatDescriptionRef desc = device.activeFormat.formatDescription;
            CMVideoDimensions dim = CMVideoFormatDescriptionGetDimensions(desc);
            NSLog(@"[APIHook] Device: %@ | 分辨率: %d x %d | 帧率: %.2f fps", 
                  device.localizedName, dim.width, dim.height,
                  (Float64)device.activeFormat.videoSupportedFrameRateRanges.lastObject.maxFrameRate);
        }
    }
    %orig;
}

%end

// ─────────────────────────────────────────────
// 辅助：每帧内存大小估算
// ─────────────────────────────────────────────
static NSString *FrameMemoryDescription(uint32_t fmt, NSInteger w, NSInteger h) {
    if (w <= 0 || h <= 0) return @"未知";
    double bytes = 0;
    switch (fmt) {
        case 0x34323076: // '420v'
        case 0x34323066: // '420f'
        case 0x26387630: // '&8v0' (Lossless)
            bytes = w * h * 1.5; break;
        case 0x78343230: // 'x420'
            bytes = w * h * 1.875; break;
        case 0x42475241: // 'BGRA'
        case 0x52474241: // 'RGBA'
            bytes = w * h * 4.0; break;
        case 0x79757673: // 'yuvs'
            bytes = w * h * 2.0; break;
        default:
            bytes = w * h * 1.5; break;
    }
    return [NSString stringWithFormat:@"%.2f MB (%ldx%ld)", bytes / (1024.0 * 1024.0), (long)w, (long)h];
}

// ─────────────────────────────────────────────
// Hook 3: CVPixelBufferPoolCreate (底层内存池)
// ─────────────────────────────────────────────
static CVReturn (*orig_CVPixelBufferPoolCreate)(
    CFAllocatorRef allocator,
    CFDictionaryRef poolAttributes,
    CFDictionaryRef pixelBufferAttributes,
    CVPixelBufferPoolRef *poolOut) = NULL;

static CVReturn hook_CVPixelBufferPoolCreate(
    CFAllocatorRef allocator,
    CFDictionaryRef poolAttributes,
    CFDictionaryRef pixelBufferAttributes,
    CVPixelBufferPoolRef *poolOut)
{
    CVReturn ret = orig_CVPixelBufferPoolCreate(allocator, poolAttributes, pixelBufferAttributes, poolOut);
    NSDictionary *poolAttrs = (__bridge NSDictionary *)poolAttributes;
    NSDictionary *bufAttrs  = (__bridge NSDictionary *)pixelBufferAttributes;

    NSNumber *minBufCount = poolAttrs[(id)kCVPixelBufferPoolMinimumBufferCountKey];
    NSNumber *width       = bufAttrs[(id)kCVPixelBufferWidthKey];
    NSNumber *height      = bufAttrs[(id)kCVPixelBufferHeightKey];

    id pixFmtRaw = bufAttrs[(id)kCVPixelBufferPixelFormatTypeKey];
    NSMutableArray<NSNumber *> *pixFmts = [NSMutableArray array];
    if ([pixFmtRaw isKindOfClass:[NSNumber class]]) [pixFmts addObject:pixFmtRaw];
    else if ([pixFmtRaw respondsToSelector:@selector(objectEnumerator)]) {
        for (id item in (id<NSFastEnumeration>)pixFmtRaw) {
            if ([item isKindOfClass:[NSNumber class]]) [pixFmts addObject:item];
        }
    }

    if (minBufCount || (width && height)) {
        NSLog(@"[APIHook] ======= CVPixelBufferPoolCreate =======");
        if (minBufCount) NSLog(@"[APIHook] 最小缓冲数(Count): %@", minBufCount);
        
        for (NSNumber *fmt in pixFmts) {
            uint32_t fmtVal = [fmt unsignedIntValue];
            NSLog(@"[APIHook] 像素格式: %@", FourCCToString(fmtVal));
            if (width && height) {
                NSLog(@"[APIHook] 每帧内存大小估算: %@", FrameMemoryDescription(fmtVal, [width integerValue], [height integerValue]));
            }
        }
    }
    return ret;
}

// ─────────────────────────────────────────────
// Hook 4: CVPixelBufferCreate (核心分配)
// ─────────────────────────────────────────────
static CVReturn (*orig_CVPixelBufferCreate)(
    CFAllocatorRef allocator,
    size_t width, size_t height,
    OSType pixelFormatType,
    CFDictionaryRef pixelBufferAttributes,
    CVPixelBufferRef *pixelBufferOut) = NULL;

static CVReturn hook_CVPixelBufferCreate(
    CFAllocatorRef allocator,
    size_t width, size_t height,
    OSType pixelFormatType,
    CFDictionaryRef pixelBufferAttributes,
    CVPixelBufferRef *pixelBufferOut)
{
    CVReturn ret = orig_CVPixelBufferCreate(allocator, width, height,
                                            pixelFormatType, pixelBufferAttributes,
                                            pixelBufferOut);
    if (ret == kCVReturnSuccess && pixelBufferOut && *pixelBufferOut) {
        CVPixelBufferRef pb = *pixelBufferOut;
        size_t dataSize = CVPixelBufferGetDataSize(pb);
        size_t rowBytes = CVPixelBufferGetBytesPerRow(pb);
        
        IOSurfaceRef surface = CVPixelBufferGetIOSurface(pb);
        size_t surfaceAllocSize = surface ? IOSurfaceGetAllocSize(surface) : 0;
        
        NSLog(@"[APIHook] ======= CVPixelBufferCreate =======");
        NSLog(@"[APIHook] 分辨率: %zux%zu | 格式: %@", width, height, FourCCToString((uint32_t)pixelFormatType));
        NSLog(@"[APIHook] 逻辑占用: %.2f MB | 物理占用(IOSurface): %.2f MB", 
              dataSize / (1024.0 * 1024.0), surfaceAllocSize / (1024.0 * 1024.0));
        NSLog(@"[APIHook] 行字节数(rowBytes): %zu bytes", rowBytes);
    }
    return ret;
}

// ─────────────────────────────────────────────
// Hook 5: App 启动类型判定 (RunningBoard 进程状态 + UIApplication 生命周期)
//
// 这段代码不针对某个具体 App，任何注入了本 dylib 的 UIApplication 进程都会跑到这些
// 判定逻辑（APIHook.plist 的 Filter 已经放宽到 com.apple.UIKit，即所有 App 进程，
// Camera / Aweme 只是先前调试相机管线时用的示例目标，不是本 Hook 的适用范围）。
//
// RBSProcessHandle / RBSProcessState 来自私有框架 RunningBoardServices.framework，
// SDK 中无公开头文件。以下声明基于对本机同型号/同版本设备
// (iPhone15,3, iOS 16.1 / 20B82，经 Xcode DeviceSupport 提取的未剥离符号表 nm 核实) 的逆向确认，
// 而非猜测：方法均已在符号表中逐一验证存在。
// NSStringFromRBSTaskState 是系统自带的枚举→可读字符串转换函数(来自 RunningBoardServices.tbd
// 的 exports 列表)，用它来解码 taskState，避免我们自己去猜测/硬编码私有枚举值含义。
// ─────────────────────────────────────────────
// RBSProcessState 上除 taskState 外的字段，其真实返回类型（对象 or 标量）无法仅凭方法名
// 100% 确定——例如 debugState 实际上和 taskState 一样是整型枚举（与导出的
// NSStringFromRBSDebugState 转换函数配对），而不是 NSString*。之前按 NSString* 声明后用
// %@ 打印，NSLog 会把这个整数当指针解引用，直接 EXC_BAD_ACCESS 崩溃，而且因为 Filter 现在是
// com.apple.UIKit，等于每个 App 一启动就崩。
// 教训：对于命名上不能 100% 确定是对象还是标量的私有属性，一律用下面的运行时安全读取，
// 而不是静态声明一个可能猜错的返回类型直接调用。
@interface RBSProcessState : NSObject
@end

@interface RBSProcessHandle : NSObject
+ (instancetype)currentProcess;
- (RBSProcessState *)currentState;
- (int)pid;
- (NSString *)name;
@end

typedef NSString *(*RBSStringFromIntFn)(NSInteger);
static RBSStringFromIntFn fn_NSStringFromRBSTaskState = NULL;
static RBSStringFromIntFn fn_NSStringFromRBSDebugState = NULL;

// 在真正调用前用 Objective-C runtime 查询该 selector 的实际返回类型编码，
// 按编码分派成对象/BOOL/整型三种安全读取路径，遇到不认识的编码直接跳过而不是硬猜。
static void LogRBSDynamicProperty(NSObject *target, SEL selector, NSString *label, RBSStringFromIntFn converter) {
    if (!target) {
        NSLog(@"[APIHook][LaunchType] %@: (target 为空)", label);
        return;
    }
    Method m = class_getInstanceMethod([target class], selector);
    if (!m) {
        NSLog(@"[APIHook][LaunchType] %@: (当前系统版本上不存在该 selector，已跳过)", label);
        return;
    }
    const char *enc = method_getTypeEncoding(m);
    char retType = enc ? enc[0] : '?';

    // arm64 上标量返回值虽然都落在 x0 寄存器，但调用方需要按“真实宽度”截断/符号扩展，
    // 否则窄类型（如下面碰到的 unsigned char 'C'）高位残留的垃圾数据会被当成有效值。
    // 所以这里按 encoding 里的真实宽度分别声明函数指针类型，而不是统一转成 NSInteger 硬调。
    if (retType == '@' || retType == '#') {
        id (*getter)(id, SEL) = (id (*)(id, SEL))[target methodForSelector:selector];
        NSLog(@"[APIHook][LaunchType] %@(对象) = %@", label, getter(target, selector));
    } else if (retType == 'B') {
        BOOL (*getter)(id, SEL) = (BOOL (*)(id, SEL))[target methodForSelector:selector];
        NSLog(@"[APIHook][LaunchType] %@ = %@", label, getter(target, selector) ? @"YES" : @"NO");
    } else if (retType == 'c') {
        char (*getter)(id, SEL) = (char (*)(id, SEL))[target methodForSelector:selector];
        char value = getter(target, selector);
        NSString *decoded = converter ? converter(value) : nil;
        NSLog(@"[APIHook][LaunchType] %@ = %@ (原始值:%d)", label, decoded ?: (value == 0 || value == 1 ? (value ? @"YES" : @"NO") : @"(无转换函数/未知含义)"), value);
    } else if (retType == 'C') {
        unsigned char (*getter)(id, SEL) = (unsigned char (*)(id, SEL))[target methodForSelector:selector];
        unsigned char value = getter(target, selector);
        NSString *decoded = converter ? converter(value) : nil;
        NSLog(@"[APIHook][LaunchType] %@ = %@ (原始值:%u)", label, decoded ?: @"(无转换函数/未知含义)", value);
    } else if (retType == 's' || retType == 'S') {
        unsigned short (*getter)(id, SEL) = (unsigned short (*)(id, SEL))[target methodForSelector:selector];
        unsigned short value = getter(target, selector);
        NSString *decoded = converter ? converter(value) : nil;
        NSLog(@"[APIHook][LaunchType] %@ = %@ (原始值:%u)", label, decoded ?: @"(无转换函数/未知含义)", value);
    } else if (retType == 'i' || retType == 'I') {
        unsigned int (*getter)(id, SEL) = (unsigned int (*)(id, SEL))[target methodForSelector:selector];
        unsigned int value = getter(target, selector);
        NSString *decoded = converter ? converter(value) : nil;
        NSLog(@"[APIHook][LaunchType] %@ = %@ (原始值:%u)", label, decoded ?: @"(无转换函数/未知含义)", value);
    } else if (retType == 'q' || retType == 'Q' || retType == 'l' || retType == 'L') {
        NSInteger (*getter)(id, SEL) = (NSInteger (*)(id, SEL))[target methodForSelector:selector];
        NSInteger value = getter(target, selector);
        NSString *decoded = converter ? converter(value) : nil;
        NSLog(@"[APIHook][LaunchType] %@ = %@ (原始值:%ld)", label, decoded ?: @"(无转换函数/未知含义)", (long)value);
    } else {
        NSLog(@"[APIHook][LaunchType] %@: 未知返回类型编码 '%s'，已跳过避免类型不匹配崩溃", label, enc ? enc : "?");
    }
}

static void LogLaunchSnapshot(NSString *checkpoint) {
    RBSProcessHandle *proc = [%c(RBSProcessHandle) currentProcess];
    RBSProcessState *state = [proc currentState];
    const char *activePrewarm = getenv("ActivePrewarm");

    NSLog(@"[APIHook][LaunchType] ======= 快照: %@ =======", checkpoint);
    NSLog(@"[APIHook][LaunchType] pid=%d name=%@", [proc pid], [proc name]);
    LogRBSDynamicProperty(state, @selector(taskState), @"taskState", fn_NSStringFromRBSTaskState);
    LogRBSDynamicProperty(state, @selector(isRunning), @"isRunning", NULL);
    LogRBSDynamicProperty(state, @selector(debugState), @"debugState", fn_NSStringFromRBSDebugState);
    LogRBSDynamicProperty(state, @selector(primitiveAssertions), @"primitiveAssertions", NULL);
    NSLog(@"[APIHook][LaunchType] ActivePrewarm 环境变量 = %s", activePrewarm ? activePrewarm : "(未设置)");
}

static BOOL sHasBecomeActiveBefore = NO;

// ─────────────────────────────────────────────
%ctor {
    NSLog(@"[APIHook] ===== Tweak Loaded =====");
    %init();

    MSHookFunction((void *)CVPixelBufferPoolCreate,
                   (void *)hook_CVPixelBufferPoolCreate,
                   (void **)&orig_CVPixelBufferPoolCreate);

    MSHookFunction((void *)CVPixelBufferCreate,
                   (void *)hook_CVPixelBufferCreate,
                   (void **)&orig_CVPixelBufferCreate);

    // dlopen 而非直接链接 RunningBoardServices：避免因框架缺失/路径变化导致启动失败，
    // 取不到符号时相关日志会明确标注，不影响其余 hook 正常工作。
    void *rbsImage = dlopen("/System/Library/PrivateFrameworks/RunningBoardServices.framework/RunningBoardServices", RTLD_NOW);
    if (rbsImage) {
        fn_NSStringFromRBSTaskState = (RBSStringFromIntFn)dlsym(rbsImage, "NSStringFromRBSTaskState");
        fn_NSStringFromRBSDebugState = (RBSStringFromIntFn)dlsym(rbsImage, "NSStringFromRBSDebugState");
    }

    NSLog(@"[APIHook][LaunchType] ActivePrewarm(进程创建时) = %s", getenv("ActivePrewarm") ? getenv("ActivePrewarm") : "(未设置)");
    LogLaunchSnapshot(@"进程起点(dylib ctor)");

    // mediaserverd 等无 UIApplication 的守护进程直接跳过生命周期监听，避免注册无意义的通知。
    if (NSClassFromString(@"UIApplication")) {
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];

        [nc addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil queue:nil usingBlock:^(NSNotification *note) {
            BOOL isPrewarm = getenv("ActivePrewarm") != NULL;
            NSLog(@"[APIHook][LaunchType] didFinishLaunching -> %@",
                  isPrewarm ? @"疑似 prewarm 冷启（系统预热进程，尚未真正前台展示）" : @"冷启（常规进程首次启动）");
            LogLaunchSnapshot(@"didFinishLaunching");
        }];

        [nc addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:nil usingBlock:^(NSNotification *note) {
            if (sHasBecomeActiveBefore) {
                NSLog(@"[APIHook][LaunchType] didBecomeActive(非首次) -> 热启/前台恢复（进程未重启，同一进程再次前台）");
            } else {
                BOOL isPrewarm = getenv("ActivePrewarm") != NULL;
                NSLog(@"[APIHook][LaunchType] didBecomeActive(首次) -> %@",
                      isPrewarm ? @"prewarm 进程被唤醒进入前台" : @"冷启直接进入前台");
            }
            sHasBecomeActiveBefore = YES;
            LogLaunchSnapshot(@"didBecomeActive");
        }];

        [nc addObserverForName:UIApplicationWillEnterForegroundNotification object:nil queue:nil usingBlock:^(NSNotification *note) {
            LogLaunchSnapshot(@"willEnterForeground");
        }];

        [nc addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:nil usingBlock:^(NSNotification *note) {
            if (!sHasBecomeActiveBefore) {
                NSLog(@"[APIHook][LaunchType] didEnterBackground(从未 didBecomeActive) -> 疑似系统后台拉起（非用户点击，如推送/定位/后台任务）");
            }
            LogLaunchSnapshot(@"didEnterBackground");
        }];
    }
}